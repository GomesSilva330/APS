package Controllers;

import Views.MainScreen;
import javax.swing.JRadioButton;

public class PointsController {
    private static int Points, Right,Wrong;
    public static int getPoints() {
        return Points;
    }
    public static int getWrongs() {
        return Wrong;
    }
    public static int getRights() {
        return Right;
    }
    public static void erasePoints() {
        MainScreen.lbPonto.setText("0");
        Points=0; 
        Right=0;
        Wrong=0;
        MainScreen.lbAcertou.setVisible(false);       
    }
    public static void CalcPoints(JRadioButton rb){
        if(rb.isSelected()){
            PointsController.setPoints();
            WidgetsController.IconRight();
        }else{
            Wrong++;
            WidgetsController.IconWrong();
        }
        WidgetsController.ProgressBarIncrease();
    }
    public static void setPoints() {
        if(FormsController.getGameActive() == "Facil")
        {
            Points += 5;
            Right++;
        }
        if(FormsController.getGameActive() == "Medio")
        {
            Points += 10;
            Right++;
        }
        if(FormsController.getGameActive() == "Dificil")
        {
            Points += 20;
            Right++;
        }
        MainScreen.lbPonto.setText(Integer.toString(Points));
    }
}
