/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controllers;

import javax.swing.JToggleButton;

/**
 *
 * @author Lucas
 */
public class ButtonsController {
    public static void ColorsOn(JToggleButton active,JToggleButton a,JToggleButton b){
        b.setSelected(false);
        a.setSelected(false);
        active.setSelected(true);
        
        active.setEnabled(false);
        a.setEnabled(true);
        b.setEnabled(true);
    }
    public static void ColorsOff(JToggleButton a, JToggleButton b, JToggleButton c){
        a.setEnabled(true);
        b.setEnabled(true);
        c.setEnabled(true);
        
        a.setSelected(false);
        b.setSelected(false);
        c.setSelected(false);
    }
}
