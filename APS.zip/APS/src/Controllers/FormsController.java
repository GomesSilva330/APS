/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controllers;

import Views.MainScreen;
import java.awt.Color;
import java.beans.PropertyVetoException;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

/**
 *
 * @author Lucas
 */
public class FormsController extends JPanel{
  
    public static void OpenForm(JDesktopPane pane, JInternalFrame frame){
        pane.add(frame);
        frame.setBackground(Color.white);
        frame.setLocation(-6,-30);
        frame.setSize(640, 445);
        frame.setUI(null);
        frame.setVisible(true);       
    }
    public static void LeaveResult(
            JDesktopPane pane,
            JToggleButton a,
            JToggleButton b,
            JToggleButton c)
    {
        PointsController.erasePoints();
        WidgetsController.ProgressBarReset();
        pane.removeAll();
        FormsController.setGameDeactive();
        ButtonsController.ColorsOff(a, b, c);
     
    }
    public static void NewGame(
            JDesktopPane pane,
            JInternalFrame frame,
            JToggleButton active,
            JToggleButton p2,
            JToggleButton p3,
            String mode)
    {
     if(getGameActive()!=null)
        { 
            int resposta = 
            JOptionPane.showConfirmDialog(null,"Deseja fechar seu jogo atual? ","Aviso!",JOptionPane.YES_NO_OPTION);
            if(resposta==JOptionPane.YES_OPTION)
            {
                pane.removeAll();
                FormsController.setGameActive(mode);
                OpenForm(pane,frame);
                ButtonsController.ColorsOn(active, p2, p3);
                PointsController.erasePoints();
                WidgetsController.ProgressBarReset();
            }
            if(resposta==JOptionPane.NO_OPTION)
            {
                try {
                    frame.setSelected(true);
                    FormsController.setGameActive(mode);
                } catch (PropertyVetoException ex) {}
            }          
        }else{
            OpenForm(pane,frame);
            ButtonsController.ColorsOn(active, p2, p3);
            FormsController.setGameActive(mode);
        }
     WidgetsController.ProgressBarColor();
    }
    public static void CloseAllForms(JDesktopPane pane,JInternalFrame frame){
        int buttonYN = 
        JOptionPane.showConfirmDialog(null,"Deseja fechar o jogo? ","Aviso!",JOptionPane.YES_NO_OPTION);
        if(buttonYN==JOptionPane.YES_OPTION)
        {
            PointsController.erasePoints();
            WidgetsController.ProgressBarReset();
            frame.dispose();
            pane.removeAll();
            setGameDeactive();
            MainScreen.jdeskTela.setVisible(false);
        }
    }
    private static String GameActive;
    public static String getGameActive() {
        return GameActive;
    }
    public static void setGameActive(String mode) {
        WidgetsController.ProgressBarReset();
        GameActive = mode;
        WidgetsController.ActiveDesk();
    }
    public static void setGameDeactive() {
        GameActive = null;
        WidgetsController.DeactiveDesk();
        WidgetsController.ActiveDesk();
        WidgetsController.ProgressBarStandBy();
    }
}
