/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Views.MainScreen;
import java.awt.Color;

/**
 *
 * @author Aluno
 */
public class WidgetsController {
   private static int n =0;
   
    public static void ProgressBarColor(){
        if (FormsController.getGameActive()=="Facil") 
            MainScreen.pbSplash.setForeground((new Color(0,255,0)));
        
         if (FormsController.getGameActive()=="Medio") 
            MainScreen.pbSplash.setForeground((new Color(255,204,0)));
          
         if (FormsController.getGameActive()=="Dificil") 
            MainScreen.pbSplash.setForeground((new Color(204,0,0)));
    }
    public static void ProgressBarReset(){
        n=0;
        MainScreen.pbSplash.setValue(n);
    } 
    public static void ProgressBarIncrease(){
        MainScreen.pbSplash.setValue(n = n+10);
    }
    public static void ProgressBarStandBy(){
        MainScreen.pbSplash.setValue(100);
        MainScreen.pbSplash.setForeground((new Color(255,220,90)));
    }
    public static void IconRight(){
       MainScreen.lbAcertou.setIcon(MainScreen.certo.getIcon());
       MainScreen.lbAcertou.setVisible(true);
    }
    public static void IconWrong(){
        MainScreen.lbAcertou.setVisible(true);
        MainScreen.lbAcertou.setIcon(MainScreen.errado.getIcon()); 
    }
    public static void DeactiveDesk(){
     MainScreen.jdeskTela.setVisible(false);
    }
    public static void ActiveDesk(){
     MainScreen.jdeskTela.setVisible(true);
    }
}
